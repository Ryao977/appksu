# 内核拦截 — KernelSU 移植版

原「SKRoot Pro · 内核拦截 v1.1.2」的 KernelSU / Magisk(Zygisk) 移植版。
**目标应用运行时，对其"设备标记目录"的访问一律返回"不存在"**，使目标应用读不到设备标记。

---

## 与原版的关系

| 维度 | 原版 (SKRoot Pro) | 本移植版 (KSU) |
|---|---|---|
| 拦截层级 | 内核级：SELinux `inode_permission` Hook + `inode_operations` 替换 | 用户空间：目标应用进程内 libc 层拦截（`open/openat/stat/lstat/statx/access/faccessat/opendir`） |
| 生效范围 | 全局（所有进程） | **仅目标应用进程**（per-app，其余进程不受影响） |
| 运行环境 | SKRoot Pro 宿主 | KernelSU v1.0.0+（或 Magisk 26.4+ 开启 Zygisk） |
| 管理界面 | 内嵌 CivetWeb | 守护进程自带极简 HTTP 服务 + 同款 WebUI |
| 默认拦截目录 | `/mnt/vendor/persist/data`（高通）、`/mnt/vendor/nvdata`（天玑） | 同左，可在 WebUI 自定义 |

**已知局限（如实说明）**：用户空间 libc 层拦截无法阻止应用以内联汇编/裸 `syscall()` 直连内核；原版内核级方案无此问题。若目标应用存在此类检测，本移植版可能失效。

## 环境要求

- 设备：ARM64（AArch64）
- 框架：KernelSU v1.0.0+（内置或安装 ZygiskNext），或 Magisk 26.4+（Zygisk 开启）
- 构建：仅需一台装有 Android NDK r27+ 的电脑（Linux / macOS）

## 构建

```bash
# 1. 下载 NDK（如 android-ndk-r27）
# 2. 在工程根目录执行：
./build.sh /path/to/android-ndk
# 产物：anti_device_flag_ksu.zip
```

## 安装

1. KernelSU Manager / Magisk App → 模块 → 从本地安装 → 选择 `anti_device_flag_ksu.zip`
2. 重启（或模块管理页启用 WebUI）

## 使用

1. 打开模块 WebUI（KernelSU Manager → 模块 → 内核拦截 → WebUI 入口）
2. 「目标应用」— 添加需要拦截的应用（手动输入包名，或从列表选择）
3. 「拦截目录」— 默认已包含高通/天玑两条标记目录，可增删
4. 「拦截日志」— 实时查看锁定/解锁、应用启动/关闭事件

配置存储在 `/data/adb/modules/anti_device_flag_ksu/config.json`，修改后**约数秒自动生效**（无需重启）。

## 安全与鉴权

- 守护进程仅监听 `127.0.0.1:16080`，不对外网开放
- **受保护接口需要令牌**（`X-Auth-Token` 请求头，逐行精确解析 + 恒等比较）：
  - 写操作：`/setTargetPkgJson`、`/setInterceptDirs`、`/clearLogs`
  - 敏感读操作：`/getTargetPkgJson`、`/getInterceptDirs`、`/getCandidatesPkgJson`
  - 首屏开放（只读、不敏感）：`/getStatus`、`/getLogs`
- **令牌为一次性手动配置**：
  1. 令牌在守护进程首次启动时随机生成（32 位 hex），仅存于 `config.json`（权限 0600，普通应用无法读取）
  2. 查看方式：终端 `cat /data/adb/modules/anti_device_flag_ksu/config.json`，或 `adb logcat -s ADFD`
  3. 在 WebUI 页面上方「API 令牌」输入框粘贴保存（仅保存在浏览器 localStorage，不落盘、不上传）
- 浏览器来源仅接受 `127.0.0.1`（KSU WebUI 页面同源）；来自其他来源的请求返回 403
- **模块事件通道（run.sock）按发送者身份鉴权**：仅接受 uid=0（root）进程上报，普通应用无法伪造事件
- HTTP 服务带请求大小上限（64KB）与接收超时（5s），防本地 DoS
- 若忘记令牌：删除 `config.json` 中的 token 字段后重启守护进程（或重装模块）即可重新生成

## 文件说明

```
anti_device_flag_ksu/
├── module.prop        # 模块元数据（KSU WebUI 模块）
├── customize.sh       # 安装钩子：生成默认配置
├── service.sh         # 启动守护进程
├── webroot/index.html # WebUI（KernelSU WebUI 协议）
├── zygisk/arm64-v8a/  # Zygisk 拦截库（构建产物）
├── system/bin/        # 守护进程（构建产物）
└── src/               # 源码
```

## 兼容性

- 与 SusFS、Shamiko 等隐藏模块**无冲突**（本模块只 hook 目标应用进程的文件访问）。
- 日志文件：`/data/adb/modules/anti_device_flag_ksu/log.txt`

## 安全说明

本模块仅作安全研究与自有设备管理用途。请勿用于绕过金融、游戏等服务的风控体系，由此产生的合规风险由使用者自行承担。