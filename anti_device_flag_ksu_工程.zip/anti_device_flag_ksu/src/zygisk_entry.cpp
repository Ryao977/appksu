/*
 * zygisk_entry.cpp - 内核拦截 (KSU 移植版) Zygisk 侧
 *
 * 功能：目标应用进程内拦截对"设备标记目录"的访问（libc 层 hook），
 *       命中路径统一返回 ENOENT，使目标应用读不到设备标记。
 * 与原版对应关系（原: 内核级 SELinux inode_permission + inode_operations 替换；
 * 本版: per-app libc 层拦截，语义等价——仅目标应用受限，其余进程不受影响）。
 */
#include "common.h"

#include <atomic>
#include <dlfcn.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>

#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <utility>
#include <vector>

#include "zygisk.hpp"

using zygisk::Api;
using zygisk::AppSpecializeArgs;
using zygisk::Option;
using zygisk::ServerSpecializeArgs;

static Api *g_api = nullptr;
static int g_sock = -1;
static std::string g_cur_pkg;   // 当前进程包名（仅目标进程有效）

/* ---------------- 进程内配置缓存（double-buffer，hook 路径零锁） ---------------- */
// writer: load_config_if_needed 构建新 buffer 后原子交换指针；
// reader(hook 路径): 原子读指针后只读不写，无数据竞争。
struct CfgBuf {
    std::vector<std::string> dirs;
    std::vector<std::string> pkgs;
};
static std::atomic<CfgBuf *> g_cfg{nullptr};
static CfgBuf *g_cfg_draft = nullptr;   // writer 专用
static long g_cfg_mtime = -2;
static bool g_enabled = false;          // 当前进程是否为目标进程

static void load_config_if_needed() {
    long mtime = adf::file_mtime_ms(adf::CONFIG_PATH);
    if (mtime < 0) return;              // 读不到（如降权后 0600 权限）：保留现有缓存
    if (mtime == g_cfg_mtime) return;
    g_cfg_mtime = mtime;
    adf::Config cfg;
    adf::config_load(adf::CONFIG_PATH, cfg);
    auto *nb = new CfgBuf;
    nb->dirs = std::move(cfg.intercept_dirs);
    nb->pkgs = std::move(cfg.target_pkgs);
    if (g_cfg_draft) delete g_cfg_draft;   // 配置更新低频，允许旧 draft 延迟释放
    g_cfg_draft = nb;
    g_cfg.store(nb, std::memory_order_release);
}

static const CfgBuf *cfg_acquire() {
    auto *p = g_cfg.load(std::memory_order_acquire);
    if (!p) {
        load_config_if_needed();
        p = g_cfg.load(std::memory_order_acquire);
    }
    return p;
}

static bool is_target_pkg(const char *pkg) {
    if (!pkg || !*pkg) return false;
    const CfgBuf *c = cfg_acquire();
    if (!c) return false;
    size_t n = strlen(pkg);
    for (const auto &p : c->pkgs) {
        if (p.size() == n && strncmp(p.c_str(), pkg, n) == 0) return true;
    }
    return false;
}

/* ---------------- cwd 缓存（相对路径判断用） ---------------- */
static char g_cwd[4096];
static long long g_cwd_ts = 0;

static void refresh_cwd() {
    long long now = adf::now_ms();
    if (now - g_cwd_ts < 100 && g_cwd[0]) return;
    if (getcwd(g_cwd, sizeof(g_cwd))) g_cwd_ts = now;
    else *g_cwd = 0;
}

static bool hit(const char *path) {
    const CfgBuf *c = cfg_acquire();
    if (!c) return false;
    if (!path || !*path) return false;
    if (path[0] == '/') return adf::path_matched(c->dirs, path);
    refresh_cwd();
    if (!g_cwd[0]) return false;
    char full[4096];
    snprintf(full, sizeof(full), "%s/%s", g_cwd, path);
    return adf::path_matched(c->dirs, full);
}

static bool dirs_ready() {
    const CfgBuf *c = cfg_acquire();
    return c && !c->dirs.empty();
}

/* 事件上报守护进程（尽力而为） */
static void report(const char *pkg, const char *action, const char *detail) {
    if (g_sock < 0) return;
    char buf[512];
    snprintf(buf, sizeof(buf),
             "{\"t\":%lld,\"pkg\":\"%s\",\"a\":\"%s\",\"d\":\"%s\"}",
             adf::now_ms(),
             adf::json_escape(pkg ? pkg : "").c_str(),
             action,
             adf::json_escape(detail ? detail : "").c_str());
    send(g_sock, buf, strlen(buf), MSG_DONTWAIT);
}

/* ---------------- 被 hook 的 libc 函数 ---------------- */
static int (*orig_open)(const char *, int, unsigned) = nullptr;
static int (*orig_openat)(int, const char *, int, unsigned) = nullptr;
static int (*orig_stat)(const char *, struct stat *) = nullptr;
static int (*orig_lstat)(const char *, struct stat *) = nullptr;
static int (*orig_statx)(int, const char *, int, unsigned, void *) = nullptr;
static int (*orig_access)(const char *, int) = nullptr;
static int (*orig_faccessat)(int, const char *, int, int) = nullptr;
static DIR *(*orig_opendir)(const char *) = nullptr;

extern "C" int hook_open(const char *path, int flags, unsigned mode) {
    if (g_enabled && hit(path)) {
        errno = ENOENT;
        report(g_cur_pkg.c_str(), "lock", path);
        return -1;
    }
    return orig_open(path, flags, mode);
}

extern "C" int hook_openat(int dirfd, const char *path, int flags, unsigned mode) {
    if (g_enabled && (dirfd == AT_FDCWD || dirfd > 0) && hit(path)) {
        errno = ENOENT;
        report(g_cur_pkg.c_str(), "lock", path);
        return -1;
    }
    return orig_openat(dirfd, path, flags, mode);
}

extern "C" int hook_stat(const char *path, struct stat *buf) {
    if (g_enabled && hit(path)) { errno = ENOENT; return -1; }
    return orig_stat(path, buf);
}

extern "C" int hook_lstat(const char *path, struct stat *buf) {
    if (g_enabled && hit(path)) { errno = ENOENT; return -1; }
    return orig_lstat(path, buf);
}

extern "C" int hook_statx(int dirfd, const char *path, int flags, unsigned mask, void *buf) {
    if (g_enabled && (dirfd == AT_FDCWD || dirfd > 0) && hit(path)) { errno = ENOENT; return -1; }
    return orig_statx(dirfd, path, flags, mask, buf);
}

extern "C" int hook_access(const char *path, int mode) {
    if (g_enabled && hit(path)) { errno = ENOENT; return -1; }
    return orig_access(path, mode);
}

extern "C" int hook_faccessat(int dirfd, const char *path, int mode, int flags) {
    if (g_enabled && (dirfd == AT_FDCWD || dirfd > 0) && hit(path)) { errno = ENOENT; return -1; }
    return orig_faccessat(dirfd, path, mode, flags);
}

extern "C" DIR *hook_opendir(const char *path) {
    if (g_enabled && hit(path)) { errno = ENOENT; return nullptr; }
    return orig_opendir(path);
}

/* ---------------- Zygisk 模块 ---------------- */
class Module : public zygisk::ModuleBase {
public:
    static auto instance() -> ModuleBase * {
        static Module mod;
        return &mod;
    }

    void onLoad(Api *api, JNIEnv *env) override {
        g_api = api;
        m_env = env;
    }

    void preAppSpecialize(AppSpecializeArgs *args) override {
        g_enabled = false;
        g_cur_pkg.clear();
        if (!m_env || !args->nice_name) return;
        const char *nice = m_env->GetStringUTFChars(args->nice_name, nullptr);
        bool target = nice && is_target_pkg(nice);
        if (target) g_cur_pkg = nice ? nice : "";
        m_env->ReleaseStringUTFChars(args->nice_name, nice);
        if (!target) {
            g_api->setOption(Option::DLCLOSE_MODULE_LIB);
        }
    }

    void postAppSpecialize(const AppSpecializeArgs *) override {
        if (!g_enabled) return;
        g_sock = socket(AF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
        if (g_sock >= 0) {
            struct sockaddr_un addr;
            memset(&addr, 0, sizeof(addr));
            addr.sun_family = AF_UNIX;
            strncpy(addr.sun_path, adf::SOCK_PATH, sizeof(addr.sun_path) - 1);
            if (connect(g_sock, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
                close(g_sock);
                g_sock = -1;
            }
        }
        if (!dirs_ready()) return;
        void *libc = dlopen("libc.so", RTLD_NOW);
        if (!libc) return;
        g_api->hookPLTReloc(libc, "open",      (void *)hook_open,      (void **)&orig_open);
        g_api->hookPLTReloc(libc, "openat",    (void *)hook_openat,    (void **)&orig_openat);
        g_api->hookPLTReloc(libc, "stat",      (void *)hook_stat,      (void **)&orig_stat);
        g_api->hookPLTReloc(libc, "lstat",     (void *)hook_lstat,     (void **)&orig_lstat);
        g_api->hookPLTReloc(libc, "statx",     (void *)hook_statx,     (void **)&orig_statx);
        g_api->hookPLTReloc(libc, "access",    (void *)hook_access,    (void **)&orig_access);
        g_api->hookPLTReloc(libc, "faccessat", (void *)hook_faccessat, (void **)&orig_faccessat);
        g_api->hookPLTReloc(libc, "opendir",   (void *)hook_opendir,   (void **)&orig_opendir);
        report(g_cur_pkg.c_str(), "detect_running", "zygisk hook installed");
    }

    void preServerSpecialize(ServerSpecializeArgs *) override {}
    void postServerSpecialize(const ServerSpecializeArgs *) override {}

private:
    JNIEnv *m_env = nullptr;
};

REGISTER_ZYGISK_MODULE(Module)