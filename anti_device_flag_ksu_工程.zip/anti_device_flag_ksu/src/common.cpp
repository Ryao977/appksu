#include "common.h"

#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <iterator>
#include <sys/stat.h>
#include <sys/time.h>
#include <unistd.h>
#include <utility>

namespace adf {

long long now_ms() {
    struct timeval tv;
    gettimeofday(&tv, nullptr);
    return (long long)tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

std::string read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return "";
    std::string out;
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) out.append(buf, n);
    fclose(f);
    return out;
}

bool write_file(const char *path, const std::string &data) {
    FILE *f = fopen(path, "wb");
    if (!f) return false;
    bool ok = fwrite(data.data(), 1, data.size(), f) == data.size();
    fclose(f);
    if (ok) chmod(path, 0666);
    return ok;
}

long file_mtime_ms(const char *path) {
    struct stat st;
    if (stat(path, &st) != 0) return -1;
    return (long)st.st_mtime * 1000 + st.st_mtim.tv_nsec / 1000000;
}

std::string json_escape(const std::string &s) {
    std::string out;
    out.reserve(s.size() + 8);
    for (unsigned char c : s) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) {
                    char b[8];
                    snprintf(b, sizeof(b), "\\u%04x", c);
                    out += b;
                } else {
                    out += (char)c;
                }
        }
    }
    return out;
}

static void skip_ws(const char **p) {
    while (**p == ' ' || **p == '\t' || **p == '\n' || **p == '\r') (*p)++;
}

bool parse_string_array(const char *json, std::vector<std::string> &out) {
    out.clear();
    const char *p = json;
    skip_ws(&p);
    if (*p != '[') return false;
    p++;
    for (;;) {
        skip_ws(&p);
        if (*p == ']') return true;
        if (*p != '"') return false;
        p++;
        std::string s;
        while (*p && *p != '"') {
            if (*p == '\\' && p[1]) {
                p++;
                switch (*p) {
                    case 'n': s += '\n'; break;
                    case 'r': s += '\r'; break;
                    case 't': s += '\t'; break;
                    case '"': s += '"'; break;
                    case '\\': s += '\\'; break;
                    default: s += *p;
                }
            } else {
                s += *p;
            }
            p++;
        }
        if (*p != '"') return false;
        p++;
        out.push_back(s);
        skip_ws(&p);
        if (*p == ',') { p++; continue; }
        if (*p == ']') return true;
        return false;
    }
}

std::string dump_string_array(const std::vector<std::string> &v) {
    std::string out = "[";
    for (size_t i = 0; i < v.size(); i++) {
        if (i) out += ",";
        out += "\"" + json_escape(v[i]) + "\"";
    }
    out += "]";
    return out;
}

bool config_load(const char *path, Config &cfg) {
    cfg = Config();
    std::string raw = read_file(path);
    if (raw.empty()) {
        // 默认配置
        cfg.intercept_dirs.assign(std::begin(DEFAULT_DIRS), std::end(DEFAULT_DIRS));
        return false;
    }
    // 极简解析：{"target_pkgs":[...],"intercept_dirs":[...],"port":N}
    // 分段查找，不做完整 JSON 树解析（配置文件由本模块自己写出，格式受控）
    bool have = false;
    auto grab_array = [&](const char *key, std::vector<std::string> &dst) {
        std::string k = std::string("\"") + key + "\"";
        size_t pos = raw.find(k);
        if (pos == std::string::npos) return;
        size_t b = raw.find('[', pos);
        if (b == std::string::npos) return;
        size_t e = raw.find(']', b);
        if (e == std::string::npos) return;
        std::vector<std::string> tmp;
        if (parse_string_array(raw.substr(b, e - b + 1).c_str(), tmp)) {
            dst = std::move(tmp);
            have = true;
        }
    };
    grab_array("target_pkgs", cfg.target_pkgs);
    grab_array("intercept_dirs", cfg.intercept_dirs);
    size_t p = raw.find("\"port\"");
    if (p != std::string::npos) {
        p = raw.find(':', p);
        if (p != std::string::npos) {
            int v = atoi(raw.c_str() + p + 1);
            if (v > 0 && v < 65536) { cfg.port = v; have = true; }
        }
    }
    size_t tk = raw.find("\"token\"");
    if (tk != std::string::npos) {
        tk = raw.find('"', tk + 7);          // 值起始引号
        if (tk != std::string::npos) {
            size_t te = raw.find('"', tk + 1);
            if (te != std::string::npos) {
                cfg.token = raw.substr(tk + 1, te - tk - 1);
                have = true;
            }
        }
    }
    if (cfg.intercept_dirs.empty())
        cfg.intercept_dirs.assign(std::begin(DEFAULT_DIRS), std::end(DEFAULT_DIRS));
    return have;
}

bool config_save(const char *path, const Config &cfg) {
    std::string out = "{\n";
    out += "  \"target_pkgs\": " + dump_string_array(cfg.target_pkgs) + ",\n";
    out += "  \"intercept_dirs\": " + dump_string_array(cfg.intercept_dirs) + ",\n";
    char b[64];
    snprintf(b, sizeof(b), "%d", cfg.port);
    out += std::string("  \"port\": ") + b + ",\n";
    out += "  \"token\": \"" + json_escape(cfg.token) + "\"\n";
    out += "}\n";
    return write_file(path, out);
}

bool path_matched(const std::vector<std::string> &dirs, const char *path) {
    if (!path || !*path) return false;
    size_t plen = strlen(path);
    for (const auto &d : dirs) {
        if (d.empty()) continue;
        if (plen == d.size() && strncmp(path, d.c_str(), plen) == 0) return true;
        if (plen > d.size() && strncmp(path, d.c_str(), d.size()) == 0 &&
            path[d.size()] == '/') return true;
    }
    return false;
}

}  // namespace adf