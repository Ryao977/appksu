#pragma once
// 共享工具：配置读写、极简 JSON、路径匹配、日志
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

namespace adf {

constexpr const char *MODULE_ID = "anti_device_flag_ksu";
// 运行期根路径（KSU/Magisk 均挂载模块到 /data/adb/modules/<id>）
constexpr const char *MODULE_DIR = "/data/adb/modules/anti_device_flag_ksu";
constexpr const char *CONFIG_PATH = "/data/adb/modules/anti_device_flag_ksu/config.json";
constexpr const char *LOG_PATH = "/data/adb/modules/anti_device_flag_ksu/log.txt";
constexpr const char *SOCK_PATH = "/data/adb/modules/anti_device_flag_ksu/run.sock";
constexpr const char *DEFAULT_DIRS[] = {"/mnt/vendor/persist/data", "/mnt/vendor/nvdata"};
constexpr const char *SOFTJSON_VER = "1";
constexpr int DEFAULT_PORT = 16080;

struct Config {
    std::vector<std::string> target_pkgs;
    std::vector<std::string> intercept_dirs;
    std::string token;      // HTTP 鉴权令牌（仅守护进程与 Zygisk 读取）
    int port = DEFAULT_PORT;
    int log_cap = 200;
};

// ---- 配置 ----
bool config_load(const char *path, Config &cfg);
bool config_save(const char *path, const Config &cfg);

// ---- 极简 JSON ----
std::string json_escape(const std::string &s);
// 解析 ["a","b"] 到 out；成功返回 true
bool parse_string_array(const char *json, std::vector<std::string> &out);
// 把 vector 序列化为 ["a","b"]
std::string dump_string_array(const std::vector<std::string> &v);

// ---- 路径匹配：path 是否命中任一拦截目录前缀 ----
bool path_matched(const std::vector<std::string> &dirs, const char *path);

// ---- 文件 ----
std::string read_file(const char *path);
bool write_file(const char *path, const std::string &data);
long file_mtime_ms(const char *path);

// ---- 时间 ----
long long now_ms();

}  // namespace adf