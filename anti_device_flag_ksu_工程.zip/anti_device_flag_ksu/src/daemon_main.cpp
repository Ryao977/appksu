/*
 * daemon_main.cpp - 内核拦截 (KSU 移植版) 守护进程
 *
 * 职责：
 *  1. 本地 HTTP 服务（127.0.0.1:16080），承载 WebUI 的 8 个 API
 *  2. 接收 Zygisk 侧事件（unix dgram），维护拦截日志/统计
 *  3. 监控目标应用运行状态（/proc 轮询），维护 running_targets
 *  4. 配置读写（config.json），热生效（Zygisk 侧按 mtime 自动重载）
 */
#include "common.h"

#include <arpa/inet.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/un.h>
#include <unistd.h>

#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <mutex>
#include <set>
#include <string>
#include <utility>
#include <vector>

#include <android/log.h>

using namespace adf;

/* ---------------- 日志 ---------------- */
struct LogEntry {
    long long t;             // 秒
    std::string pkg, action, detail;
};

static std::mutex g_log_mtx;
static std::deque<LogEntry> g_logs;
static int g_log_cap = 200;
static long long g_total_intercepts = 0;

static void add_log(const char *pkg, const char *action, const char *detail) {
    std::lock_guard<std::mutex> lk(g_log_mtx);
    LogEntry e;
    e.t = now_ms() / 1000;
    e.pkg = pkg ? pkg : "";
    e.action = action ? action : "";
    e.detail = detail ? detail : "";
    g_logs.push_back(std::move(e));
    if ((int)g_logs.size() > g_log_cap) g_logs.pop_front();
    if (std::string(action) == "lock") g_total_intercepts++;
    FILE *f = fopen(LOG_PATH, "ab");
    if (f) {
        fprintf(f, "[%lld] %s %s %s\n", e.t, e.action.c_str(), e.pkg.c_str(), e.detail.c_str());
        fclose(f);
    }
}

/* ---------------- 运行状态 ---------------- */
static std::mutex g_run_mtx;
static std::set<std::string> g_running;   // 当前运行中的目标包名
static long long g_start_ms = 0;

static bool proc_is_target(const char *cmdline, const std::vector<std::string> &pkgs,
                           std::string &out_pkg) {
    for (const auto &p : pkgs) {
        size_t n = p.size();
        if (strncmp(cmdline, p.c_str(), n) == 0 &&
            (cmdline[n] == '\0' || cmdline[n] == ':')) {
            out_pkg = p;
            return true;
        }
    }
    return false;
}

static void *proc_monitor(void *) {
    Config cfg;
    config_load(CONFIG_PATH, cfg);
    for (;;) {
        // 轮询全部进程 cmdline
        std::set<std::string> now_running;
        config_load(CONFIG_PATH, cfg);  // 每轮重读，保持配置热生效
        std::vector<std::string> pkgs = cfg.target_pkgs;
        DIR *d = opendir("/proc");
        if (d) {
            struct dirent *e;
            while ((e = readdir(d))) {
                if (e->d_name[0] < '0' || e->d_name[0] > '9') continue;
                char path[64], line[1024];
                snprintf(path, sizeof(path), "/proc/%s/cmdline", e->d_name);
                FILE *f = fopen(path, "rb");
                if (!f) continue;
                size_t n = fread(line, 1, sizeof(line) - 1, f);
                fclose(f);
                line[n] = '\0';
                std::string pkg;
                if (n > 0 && proc_is_target(line, pkgs, pkg)) now_running.insert(pkg);
            }
            closedir(d);
        }
        std::lock_guard<std::mutex> lk(g_run_mtx);
        for (const auto &p : now_running)
            if (!g_running.count(p)) add_log(p.c_str(), "detect_running", "proc monitor");
        for (const auto &p : g_running)
            if (!now_running.count(p)) add_log(p.c_str(), "detect_close", "proc monitor");
        g_running = std::move(now_running);
        sleep(2);
    }
    return nullptr;
}

/* ---------------- 事件通道（Zygisk -> daemon） ---------------- */
static void *event_loop(void *) {
    int fd = socket(AF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
    if (fd < 0) return nullptr;
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, SOCK_PATH, sizeof(addr.sun_path) - 1);
    unlink(SOCK_PATH);
    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
        close(fd);
        return nullptr;
    }
    chmod(SOCK_PATH, 0666);
    char buf[1024];
    for (;;) {
        ssize_t n = recv(fd, buf, sizeof(buf) - 1, 0);
        if (n <= 0) continue;
        // 身份校验：仅接受 root(uid 0) 发送者（Zygisk hook 阶段进程为 root；
        // 普通应用可写 socket 但无法伪造 SO_PEERCRED）
        struct ucred cred;
        socklen_t clen = sizeof(cred);
        if (getsockopt(fd, SOL_SOCKET, SO_PEERCRED, &cred, &clen) != 0 || cred.uid != 0)
            continue;
        buf[n] = '\0';
        // 极简解析 {"t":..,"pkg":"..","a":"lock","d":".."}
        Config cfg;
        config_load(CONFIG_PATH, cfg);
        std::string raw = buf;
        auto grab = [&](const char *key, std::string &out) {
            std::string k = std::string("\"") + key + "\"";
            size_t p = raw.find(k);
            if (p == std::string::npos) return;
            p = raw.find('"', p + k.size());
            if (p == std::string::npos) return;
            size_t e = raw.find('"', p + 1);
            if (e == std::string::npos) return;
            out = raw.substr(p + 1, e - p - 1);
        };
        std::string pkg, act, det;
        grab("pkg", pkg);
        grab("a", act);
        grab("d", det);
        add_log(pkg.c_str(), act.c_str(), det.c_str());
    }
}

/* ---------------- HTTP ---------------- */
/* 鉴权：受保护 API 要求 X-Auth-Token 精确匹配 config.token（逐行解析请求头）；
 * 浏览器来源仅允许 127.0.0.1（KSU WebUI 页面）。
 * 令牌不再落盘 webroot（避免被本地进程经 ksud 静态文件通道窃取），
 * 由用户在终端获取后填入 WebUI（localStorage 保存）。 */
static std::string g_token_cache;

static bool header_token_valid(const std::string &headers) {
    if (g_token_cache.empty()) return false;
    // 逐行解析（第一行为请求行，自然跳过）
    size_t pos = 0;
    while (pos <= headers.size()) {
        size_t eol = headers.find("\r\n", pos);
        std::string line = (eol == std::string::npos)
                               ? headers.substr(pos)
                               : headers.substr(pos, eol - pos);
        // 前缀 "x-auth-token:" 大小写不敏感比较（长度 13）
        if (line.size() > 13) {
            static const char pfx[] = "x-auth-token:";
            bool pre = true;
            for (size_t i = 0; i < 13; i++) {
                char a = line[i];
                if (a >= 'A' && a <= 'Z') a = (char)(a - 'A' + 'a');
                if (a != pfx[i]) { pre = false; break; }
            }
            if (pre) {
                std::string val = line.substr(13);
                size_t s = val.find_first_not_of(" \t");
                size_t e2 = val.find_last_not_of(" \t");
                if (s == std::string::npos) return false;   // 空令牌视为拒绝
                val = val.substr(s, e2 - s + 1);
                return val == g_token_cache;                // 恒等比较
            }
        }
        if (eol == std::string::npos) break;
        pos = eol + 2;
    }
    return false;
}

static bool origin_ok(const std::string &headers) {
    // 无 Origin（非浏览器客户端）放行，交由 token 校验；有 Origin 必须为 127.0.0.1
    size_t p = headers.find("\r\nOrigin:");
    if (p == std::string::npos) p = headers.find("\r\norigin:");
    if (p == std::string::npos) return true;
    size_t e = headers.find("\r\n", p + 2);   // 从该行内容起找行尾，避免匹配到行首
    std::string origin = headers.substr(
        p + 9, e == std::string::npos ? std::string::npos : e - p - 9);
    // 容错 "Origin:  value" 的空格
    size_t s = origin.find_first_not_of(" \t");
    if (s == std::string::npos) return false;
    size_t e2 = origin.find_last_not_of(" \t");
    origin = origin.substr(s, e2 - s + 1);
    // 必须以 "http://127.0.0.1" 开头（16 字符），其后只能是 ':'（端口）或结束；
    // 防止 "http://127.0.0.1.evil.com" 式绕过
    if (origin.size() < 16) return false;
    if (origin.compare(0, 16, "http://127.0.0.1") != 0) return false;
    return origin.size() == 16 || origin[16] == ':';
}

static std::string json_resp(const char *body) {
    return body;
}

static void send_all(int fd, const char *s, size_t n) {
    while (n > 0) {
        ssize_t w = write(fd, s, n);
        if (w <= 0) return;
        s += w;
        n -= (size_t)w;
    }
}

static void http_reply(int fd, int code, const char *ct, const std::string &body) {
    char head[512];
    snprintf(head, sizeof(head),
             "HTTP/1.1 %d %s\r\n"
             "Content-Type: %s\r\n"
             "Content-Length: %zu\r\n"
             "Access-Control-Allow-Origin: *\r\n"
             "Access-Control-Allow-Methods: POST, OPTIONS\r\n"
             "Access-Control-Allow-Headers: Content-Type, X-Auth-Token\r\n"
             "Connection: close\r\n"
             "\r\n",
             code,
             code == 200 ? "OK" : (code == 403 ? "Forbidden" : "Bad Request"),
             ct, body.size());
    send_all(fd, head, strlen(head));
    send_all(fd, body.data(), body.size());
}

/* /getStatus */
static std::string status_json() {
    Config cfg;
    config_load(CONFIG_PATH, cfg);
    std::string running = "[";
    bool first = true;
    {
        std::lock_guard<std::mutex> lk(g_run_mtx);
        for (const auto &p : g_running) {
            if (!first) running += ",";
            running += "\"" + json_escape(p) + "\"";
            first = false;
        }
    }
    running += "]";
    char b[256];
    snprintf(b, sizeof(b),
             "{\"current_locked\":%d,\"total_intercepts\":%lld,\"uptime\":%lld,"
             "\"running_targets\":%s,\"daemon_running\":1,\"port\":%d}",
             (g_running.empty() ? 0 : 1), g_total_intercepts,
             (now_ms() - g_start_ms) / 1000, running.c_str(), cfg.port);
    return b;
}

/* /getLogs */
static std::string logs_json() {
    std::string out = "[";
    bool first = true;
    std::lock_guard<std::mutex> lk(g_log_mtx);
    for (const auto &l : g_logs) {
        if (!first) out += ",";
        first = false;
        out += "{\"time\":" + std::to_string(l.t) +
               ",\"pkg\":\"" + json_escape(l.pkg) +
               "\",\"action\":\"" + json_escape(l.action) +
               "\",\"detail\":\"" + json_escape(l.detail) + "\"}";
    }
    out += "]";
    return out;
}

/* /getCandidatesPkgJson -> [{packageName,label}] */
static std::string candidates_json() {
    std::string raw = read_file("/data/system/packages.list");
    std::vector<std::string> pkgs;
    size_t pos = 0;
    while (pos < raw.size()) {
        size_t eol = raw.find('\n', pos);
        if (eol == std::string::npos) eol = raw.size();
        std::string line = raw.substr(pos, eol - pos);
        pos = eol + 1;
        size_t tab = line.find(' ');
        std::string pkg = (tab == std::string::npos) ? line : line.substr(0, tab);
        if (!pkg.empty()) pkgs.push_back(pkg);
    }
    std::string out = "[";
    for (size_t i = 0; i < pkgs.size(); i++) {
        if (i) out += ",";
        out += "{\"packageName\":\"" + json_escape(pkgs[i]) +
               "\",\"label\":\"" + json_escape(pkgs[i]) + "\"}";
    }
    out += "]";
    return out;
}

static void handle_request(int fd, const char *method, const char *path,
                           const std::string &body, const std::string &headers) {
    if (strcmp(method, "OPTIONS") == 0) {
        http_reply(fd, 200, "text/plain", "");
        return;
    }
    // 受保护 API：写操作 + 敏感读操作（getStatus/getLogs 首屏开放）
    static const char *protected_apis[] = {
        "/setTargetPkgJson", "/setInterceptDirs", "/clearLogs",
        "/getTargetPkgJson", "/getInterceptDirs", "/getCandidatesPkgJson"
    };
    for (const char *wa : protected_apis) {
        if (strcmp(path, wa) == 0) {
            if (!origin_ok(headers) || !header_token_valid(headers)) {
                http_reply(fd, 403, "application/json", "{\"ok\":0,\"err\":\"forbidden\"}");
                return;
            }
            break;
        }
    }
    if (strcmp(path, "/getStatus") == 0) {
        http_reply(fd, 200, "application/json", status_json());
    } else if (strcmp(path, "/getLogs") == 0) {
        http_reply(fd, 200, "application/json", logs_json());
    } else if (strcmp(path, "/clearLogs") == 0) {
        {
            std::lock_guard<std::mutex> lk(g_log_mtx);
            g_logs.clear();
            g_total_intercepts = 0;
        }
        unlink(LOG_PATH);
        add_log("", "config_update", "logs cleared");
        http_reply(fd, 200, "application/json", "{\"ok\":1}");
    } else if (strcmp(path, "/getTargetPkgJson") == 0) {
        Config cfg;
        config_load(CONFIG_PATH, cfg);
        http_reply(fd, 200, "application/json", dump_string_array(cfg.target_pkgs));
    } else if (strcmp(path, "/setTargetPkgJson") == 0) {
        Config cfg;
        config_load(CONFIG_PATH, cfg);
        if (parse_string_array(body.c_str(), cfg.target_pkgs)) {
            config_save(CONFIG_PATH, cfg);
            add_log("", "config_update", "target pkgs updated");
            http_reply(fd, 200, "application/json", "{\"ok\":1}");
        } else {
            http_reply(fd, 400, "application/json", "{\"ok\":0,\"err\":\"bad array\"}");
        }
    } else if (strcmp(path, "/getCandidatesPkgJson") == 0) {
        http_reply(fd, 200, "application/json", candidates_json());
    } else if (strcmp(path, "/getInterceptDirs") == 0) {
        Config cfg;
        config_load(CONFIG_PATH, cfg);
        http_reply(fd, 200, "application/json", dump_string_array(cfg.intercept_dirs));
    } else if (strcmp(path, "/setInterceptDirs") == 0) {
        Config cfg;
        config_load(CONFIG_PATH, cfg);
        if (parse_string_array(body.c_str(), cfg.intercept_dirs)) {
            config_save(CONFIG_PATH, cfg);
            add_log("", "dir_config", "intercept dirs updated");
            http_reply(fd, 200, "application/json", "{\"ok\":1}");
        } else {
            http_reply(fd, 400, "application/json", "{\"ok\":0,\"err\":\"bad array\"}");
        }
    } else {
        http_reply(fd, 404, "text/plain", "not found");
    }
}

static void *http_server(void *) {
    Config cfg;
    config_load(CONFIG_PATH, cfg);
    int srv = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (srv < 0) return nullptr;
    int one = 1;
    setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    struct sockaddr_in in;
    memset(&in, 0, sizeof(in));
    in.sin_family = AF_INET;
    in.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    in.sin_port = htons((uint16_t)cfg.port);
    if (bind(srv, (struct sockaddr *)&in, sizeof(in)) != 0) {
        perror("bind");
        close(srv);
        return nullptr;
    }
    if (listen(srv, 8) != 0) {
        close(srv);
        return nullptr;
    }
    add_log("", "daemon_start", "http listening");
    for (;;) {
        int cli = accept(srv, nullptr, nullptr);
        if (cli < 0) continue;
        // 防止异常客户端挂住 HTTP 服务
        struct timeval tv;
        tv.tv_sec = 5;
        tv.tv_usec = 0;
        setsockopt(cli, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        // 读取请求头 + body（总量上限 64KB，防内存耗尽）
        const size_t kMaxReq = 65536;
        char buf[8192];
        std::string req;
        size_t body_len = 0;
        for (;;) {
            ssize_t n = read(cli, buf, sizeof(buf));
            if (n <= 0) break;
            req.append(buf, (size_t)n);
            if (req.size() > kMaxReq) { close(cli); goto next_conn; }
            size_t hd = req.find("\r\n\r\n");
            if (hd != std::string::npos) {
                size_t cl = req.find("Content-Length:");
                if (cl != std::string::npos) {
                    body_len = (size_t)strtoul(req.c_str() + cl + 15, nullptr, 10);
                }
                if (body_len > kMaxReq) {   // 声明超大 body：直接拒绝
                    http_reply(cli, 413, "application/json", "{\"ok\":0,\"err\":\"too large\"}");
                    close(cli);
                    goto next_conn;
                }
                if (req.size() >= hd + 4 + body_len) break;
            }
        }
        std::string method, path;
        size_t sp1 = req.find(' ');
        if (sp1 != std::string::npos) {
            method = req.substr(0, sp1);
            size_t sp2 = req.find(' ', sp1 + 1);
            path = (sp2 == std::string::npos) ? "" : req.substr(sp1 + 1, sp2 - sp1 - 1);
        }
        std::string body;
        size_t hd = req.find("\r\n\r\n");
        std::string headers;
        if (hd != std::string::npos) {
            body = req.substr(hd + 4);
            headers = req.substr(0, hd);
        }
        handle_request(cli, method.c_str(), path.c_str(), body, headers);
        close(cli);
        continue;
    next_conn:;
    }
}

/* ---------------- main ---------------- */
/* 令牌：首次启动生成随机 32 位 hex，仅写入 config.json(600)；不落盘 webroot */
static void ensure_token() {
    Config cfg;
    config_load(CONFIG_PATH, cfg);
    if (cfg.token.size() != 32) {
        std::string tk;
        tk.reserve(32);
        FILE *u = fopen("/dev/urandom", "rb");
        if (!u) return;
        unsigned char buf[16];
        if (fread(buf, 1, sizeof(buf), u) != sizeof(buf)) { fclose(u); return; }
        fclose(u);
        static const char hex[] = "0123456789abcdef";
        for (unsigned char b : buf) {
            tk += hex[b >> 4];
            tk += hex[b & 0xf];
        }
        cfg.token = tk;
        config_save(CONFIG_PATH, cfg);
    }
    g_token_cache = cfg.token;
    chmod(CONFIG_PATH, 0600);
    // 令牌仅存于 0600 的 config.json，不落盘 webroot（避免被本地进程窃取）。
    // 用户通过终端查看：cat /data/adb/modules/anti_device_flag_ksu/config.json
    // 或 adb logcat -s ADFD（普通应用无 READ_LOGS 权限读不到）。
    __android_log_print(ANDROID_LOG_INFO, "ADFD", "auth token: %s",
                        g_token_cache.c_str());
}

int main() {
    signal(SIGPIPE, SIG_IGN);
    g_start_ms = now_ms();
    ensure_token();
    Config cfg;
    config_load(CONFIG_PATH, cfg);
    g_log_cap = 200;

    // 首次运行补默认配置
    add_log("", "init", MODULE_ID " daemon starting");

    pthread_t t1, t2, t3;
    pthread_create(&t1, nullptr, event_loop, nullptr);
    pthread_create(&t2, nullptr, proc_monitor, nullptr);
    pthread_create(&t3, nullptr, http_server, nullptr);
    pthread_join(t1, nullptr);
    return 0;
}