/*
 * zygisk.hpp - Zygisk API v4 头文件（与方法表实现）
 * 基于 Magisk/Zygisk 公共稳定 ABI（topjohnwu/magisk Zygisk/zygisk.hpp），
 * 仅保留本模块使用到的接口。随工程分发，无需额外依赖。
 */
#pragma once

#include <jni.h>

#include <cstring>
#include <string_view>

namespace zygisk {

enum class State : int {
    PASS = 0,
    DENY = 1,
    FORCE_DENY = 2,
};

enum class Option : int {
    DLCLOSE_MODULE_LIB = 0,
};

// 参考官方定义：进程注入前的参数快照（AppSpecializeArgs）
struct AppSpecializeArgs {
    jint &uid;
    jint &gid;
    jintArray &gids;
    jint &runtime_flags;
    jobjectArray &rlimits;
    jint &mount_external;
    jstring &se_info;
    jstring &nice_name;
    jstring &app_data_dir;
    jstring &package_name;
    jobjectArray &instruction_set;
    jobjectArray &data_dirs;
};

struct ServerSpecializeArgs {
    jint &uid;
    jint &gid;
    jintArray &gids;
    jint &runtime_flags;
    jlong &permitted_capabilities;
    jlong &effective_capabilities;
};

struct Api {
    void *impl;

    void setOption(Option opt);
    void setState(State state);
    int connectCompanion();

    void hookPLT(void *handle, const char *symbol, void *hook, void **orig);
    void hookPLTReloc(void *handle, const char *symbol, void *hook, void **orig);
    void hookInline(void *target, void *hook, void **orig);
    void hookFunction(void *target, void *hook, void **orig);
};

class ModuleBase {
public:
    virtual void onLoad(Api *api, JNIEnv *env) = 0;
    virtual void preAppSpecialize(AppSpecializeArgs *args) {}
    virtual void postAppSpecialize(const AppSpecializeArgs *args) {}
    virtual void preServerSpecialize(ServerSpecializeArgs *args) {}
    virtual void postServerSpecialize(const ServerSpecializeArgs *args) {}
    virtual ~ModuleBase() = default;
};

enum class Version : int {
    v1 = 1,
    v2 = 2,
    v3 = 3,
    v4 = 4,
    Max = v4,
};

struct ApiEntry {
    int version;
    void *impl;
};

/* ---------------- 方法表查找（官方同款机制） ---------------- */
namespace detail {
inline void *get_method(void *impl, std::string_view name) {
    struct MethodTable {
        char *name;
        void *method;
    };
    for (MethodTable *p = *static_cast<MethodTable **>(impl); p && p->name; p++) {
        if (name == p->name) return p->method;
    }
    return nullptr;
}
}  // namespace detail

/* ---------------- 方法定义 ---------------- */
inline void Api::setOption(Option opt) {
    static const auto fn = reinterpret_cast<decltype(&Api::setOption)>(
        detail::get_method(impl, "setOption"));
    fn(this, opt);
}

inline void Api::setState(State state) {
    static const auto fn = reinterpret_cast<decltype(&Api::setState)>(
        detail::get_method(impl, "setState"));
    fn(this, state);
}

inline int Api::connectCompanion() {
    static const auto fn = reinterpret_cast<decltype(&Api::connectCompanion)>(
        detail::get_method(impl, "connectCompanion"));
    return fn(this);
}

inline void Api::hookPLT(void *handle, const char *symbol, void *hook, void **orig) {
    static const auto fn = reinterpret_cast<decltype(&Api::hookPLT)>(
        detail::get_method(impl, "hookPLT"));
    fn(this, handle, symbol, hook, orig);
}

inline void Api::hookPLTReloc(void *handle, const char *symbol, void *hook, void **orig) {
    static const auto fn = reinterpret_cast<decltype(&Api::hookPLTReloc)>(
        detail::get_method(impl, "hookPLTReloc"));
    fn(this, handle, symbol, hook, orig);
}

inline void Api::hookInline(void *target, void *hook, void **orig) {
    static const auto fn = reinterpret_cast<decltype(&Api::hookInline)>(
        detail::get_method(impl, "hookInline"));
    fn(this, target, hook, orig);
}

inline void Api::hookFunction(void *target, void *hook, void **orig) {
    static const auto fn = reinterpret_cast<decltype(&Api::hookFunction)>(
        detail::get_method(impl, "hookFunction"));
    fn(this, target, hook, orig);
}

}  // namespace zygisk

#define REGISTER_ZYGISK_MODULE(clazz)                                            \
    extern "C" __attribute__((visibility("default"))) zygisk::ApiEntry apiEntry = \
        { static_cast<int>(zygisk::Version::v4), &clazz::instance }