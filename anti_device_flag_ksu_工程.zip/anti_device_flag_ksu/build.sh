#!/usr/bin/env bash
# ============================================================
# 内核拦截 (KSU 移植版) — 一键构建脚本
# 用法: ./build.sh /path/to/android-ndk  (NDK r27+)
# 产物: anti_device_flag_ksu.zip（可直接刷入 KSU / Magisk）
# ============================================================
set -euo pipefail

NDK="${1:?用法: ./build.sh /path/to/android-ndk}"
API=29
TRIPLE=aarch64-linux-android

# 宿主平台自动检测（NDK 工具链目录名因主机而异）
case "$(uname -s)-$(uname -m)" in
    Linux-x86_64)       ARCH_DIR=linux-x86_64 ;;
    Linux-aarch64)      ARCH_DIR=linux-aarch64 ;;
    Darwin-x86_64)      ARCH_DIR=darwin-x86_64 ;;
    Darwin-arm64)       ARCH_DIR=darwin-x86_64 ;;   # NDK 未提供 darwin-arm64，用 x86_64 目录
    *) echo "错误: 不支持的主机平台 $(uname -s)-$(uname -m)"; exit 1 ;;
esac

TOOLCHAIN="$NDK/toolchains/llvm/prebuilt/$ARCH_DIR"
CC="$TOOLCHAIN/bin/${TRIPLE}${API}-clang"
CXX="$TOOLCHAIN/bin/${TRIPLE}${API}-clang++"
STRIP="$TOOLCHAIN/bin/llvm-strip"

[ -x "$CXX" ] || { echo "错误: 找不到 $CXX"; exit 1; }

echo "[1/3] 编译 Zygisk 模块 ..."
"$CXX" -std=c++17 -fPIC -shared -O2 -fvisibility=hidden -Wall -Wextra \
    -Isrc src/zygisk_entry.cpp src/common.cpp \
    -o zygisk/arm64-v8a/libanti_device_flag_zygisk.so

echo "[2/3] 编译守护进程 ..."
"$CXX" -std=c++17 -O2 -static-libstdc++ -Wall -Wextra \
    -Isrc src/daemon_main.cpp src/common.cpp -llog \
    -o system/bin/anti_device_flag_daemon

"$STRIP" zygisk/arm64-v8a/libanti_device_flag_zygisk.so
"$STRIP" system/bin/anti_device_flag_daemon

chmod 755 system/bin/anti_device_flag_daemon
chmod 755 service.sh customize.sh

echo "[3/3] 打包 zip ..."
rm -f anti_device_flag_ksu.zip
if command -v zip >/dev/null 2>&1; then
    zip -q -r anti_device_flag_ksu.zip \
        module.prop customize.sh service.sh webroot zygisk system
else
    # 无 zip 命令时的 Python 回退
    python3 - <<'PYEOF'
import zipfile, os
zf = zipfile.ZipFile('anti_device_flag_ksu.zip', 'w', zipfile.ZIP_DEFLATED)
for root, _, files in os.walk('.'):
    for f in files:
        p = os.path.join(root, f)
        zf.write(p, os.path.relpath(p, '.'))
zf.close()
PYEOF
fi

echo "完成: $(pwd)/anti_device_flag_ksu.zip"
echo "刷入方式: KernelSU Manager -> 模块 -> 从本地安装"