#!/system/bin/sh
# anti_device_flag_ksu - 安装/更新钩子
MODDIR=${0%/*}

# 首次安装生成默认配置
if [ ! -f "$MODDIR/config.json" ]; then
    cat > "$MODDIR/config.json" <<'EOF'
{
  "target_pkgs": [],
  "intercept_dirs": [
    "/mnt/vendor/persist/data",
    "/mnt/vendor/nvdata"
  ],
  "port": 16080
}
EOF
    chmod 0666 "$MODDIR/config.json"
fi

exit 0