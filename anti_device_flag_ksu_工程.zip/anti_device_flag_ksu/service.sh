#!/system/bin/sh
# anti_device_flag_ksu - 守护进程启动
MODDIR=${0%/*}

# 等模块目录就绪
until [ -d "$MODDIR" ]; do sleep 1; done

# 已存在则跳过
[ -f "$MODDIR/run.pid" ] && kill -0 "$(cat "$MODDIR/run.pid" 2>/dev/null)" 2>/dev/null && exit 0

if [ -x "$MODDIR/system/bin/anti_device_flag_daemon" ]; then
    "$MODDIR/system/bin/anti_device_flag_daemon" &
    echo $! > "$MODDIR/run.pid"
fi

exit 0