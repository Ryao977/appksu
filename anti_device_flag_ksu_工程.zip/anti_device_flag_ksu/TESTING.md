# 真机验收清单（anti_device_flag_ksu）

> 用途：NDK 构建 → 刷入 → 逐项验收 → 收集反馈日志。
> 预期耗时：30-60 分钟。

## 一、构建

```bash
# 环境：Linux / macOS，Android NDK r27+（下载解压到任意目录）
./build.sh /path/to/android-ndk
# 产物：anti_device_flag_ksu.zip
```

**构建若报错**，记录完整错误信息（前 20 行即可），回报时注明：
- NDK 版本号（如 r27c）
- 报错所在步骤（[1/3] 还是 [2/3]）

## 二、安装

1. KernelSU Manager（或 Magisk App，Zygisk 已开启）→ 模块 → 从本地安装 → 选 `anti_device_flag_ksu.zip`
2. 重启设备
3. 检查模块状态为"已启用"，WebUI 入口可见

## 三、基础功能验收

| # | 步骤 | 预期 |
|---|---|---|
| 1 | 打开 WebUI | 页面加载，"连接中"变为正常状态；顶部无"未授权"提示 |
| 2 | 添加目标应用（手动输入一个测试包名） | 提示保存成功；重新打开页面名单仍在 |
| 3 | 「拦截目录」显示两条默认目录 | `/mnt/vendor/persist/data`、`/mnt/vendor/nvdata` |
| 4 | 启动目标应用 | 日志出现 `detect_running`；状态区"拦截中"计数 +1 |
| 5 | 目标应用内访问拦截目录（如有检测入口） | 读取失败/显示不存在（ENOENT） |
| 6 | 退出目标应用 | 日志出现 `detect_close` |
| 7 | 非目标应用 | 行为不受影响（访问拦截目录正常） |

## 四、鉴权加固验收（本次改动重点）

| # | 步骤 | 预期 |
|---|---|---|
| 8 | 终端 `cat /data/adb/modules/anti_device_flag_ksu/config.json` | 有 `"token": "<32位hex>"`；文件权限 600 |
| 9 | 不填令牌直接点"添加应用" | 页面 toast「未授权：请先填写 API 令牌」，操作被拒绝 |
| 10 | WebUI 页面上方粘贴令牌并保存 | 添加/删除应用、改目录、清空日志全部可用 |
| 11 | `adb logcat -s ADFD` | 能看到 `auth token: <32位hex>`（与 config.json 一致） |
| 12 | 令牌输入框填入错误值（改 1 位） | 写操作被拒（403），页面提示未授权 |
| 13 | 清除令牌后刷新页面 | 仍需重新填写才能修改配置 |
| 14 | 普通 App 模拟（开发者用 curl/HTTP 工具从 shell 非 root 抑或普通 uid 进程发起） | 无令牌 → 403；伪造 `X-Origin` → 403 |
| 15 | `curl "http://127.0.0.1:16080/getStatus"`（root shell） | 返回 JSON 状态（首屏接口开放设计） |
| 16 | 事件通道：shell 以非 root 写 run.sock 伪造事件 | 日志**不出现**伪造条目（SO_PEERCRED uid 校验） |
| 17 | 大 body 请求（>64KB POST） | 返回 413 或断开，守护进程不崩溃、不卡死 |

## 五、疑似问题时的取证（回报时附上）

以下任选，越多越好：
1. `adb logcat -d -s ADFD:* Zygisk:* KernelSU:* | tail -200`
2. 守护进程日志：`cat /data/adb/modules/anti_device_flag_ksu/log.txt`
3. 配置快照：`cat /data/adb/modules/anti_device_flag_ksu/config.json`
4. 守护进程是否存活：`ps -A | grep anti_device_flag`
5. 触发问题的那一步操作描述 + 页面截图/报错文案

## 六、已知风险点（先声明，出问题不意外）

- Zygisk ABI v4 方法表按公开接口实现，若框架版本差异导致 `preAppSpecialize` 不触发，现象是"目标应用不拦截"（日志无 detect_running）
- `SO_PEERCRED` 在个别内核/框架上若获取失败，现象是"日志完全没有事件"（守护进程丢弃）——可临时关闭 uid 校验验证（回报时说明）
- 若 KSU 无 WebUI 入口（老版本 ksud），模块不影响拦截功能本身，仅管理界面不可用

## 七、验收结论回报格式（复制填写）

```
构建: 成功/失败(贴错误)
安装: 成功/失败
模块状态: 启用/未启用
基础功能 1-7: 通过项/失败项(编号+现象)
鉴权 8-17: 通过项/失败项(编号+现象)
日志文件: 已附/未附
备注:
```