#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
逻辑级预验收：逐行复刻 daemon_main.cpp 的鉴权与路由逻辑（与 C++ 实现 1:1 对应），
在无 NDK/真机环境下提前暴露逻辑缺陷。真机行为以实际运行结果为准。
"""
import re

TOKEN = "0123456789abcdef0123456789abcdef"   # 模拟 32 位 hex 令牌
PASS, FAIL = 0, 0
def check(name, got, want):
    global PASS, FAIL
    ok = got == want
    PASS += ok; FAIL += (not ok)
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}: got={got!r} want={want!r}")

# ---------------------------------------------------------------
# 1) header_token_valid —— 逐行解析 + 恒等比较（复刻 daemon_main.cpp）
# ---------------------------------------------------------------
def header_token_valid(headers):
    if not TOKEN: return False
    pos = 0
    while pos <= len(headers):
        eol = headers.find("\r\n", pos)
        line = headers[pos:] if eol == -1 else headers[pos:eol]
        if len(line) > 13:
            pre = True
            for i in range(13):
                a = line[i]
                if 'A' <= a <= 'Z': a = chr(ord(a) - ord('A') + ord('a'))
                if a != "x-auth-token:"[i]: pre = False; break
            if pre:
                val = line[13:]
                s = len(val) - len(val.lstrip(" \t"))
                e2 = len(val.rstrip(" \t"))
                if s >= e2: return False
                val = val[s:e2]
                return val == TOKEN
        if eol == -1: break
        pos = eol + 2
    return False

# 2) origin_ok —— 前缀 + 端口边界（复刻修复后实现）
def origin_ok(headers):
    p = headers.find("\r\nOrigin:")
    if p == -1: p = headers.find("\r\norigin:")
    if p == -1: return True
    e = headers.find("\r\n", p+2)   # 从该行内容起找行尾
    origin = headers[p+9:] if e == -1 else headers[p+9:e]
    s = len(origin) - len(origin.lstrip(" \t"))
    if s >= len(origin): return False
    e2 = len(origin.rstrip(" \t"))
    origin = origin[s:e2]
    if len(origin) < 16: return False
    if origin[:16] != "http://127.0.0.1": return False
    return len(origin) == 16 or origin[16] == ':'

REQ = "POST /getStatus HTTP/1.1\r\n"   # 真实请求头前缀
H = lambda s: REQ + s

# 3) protected 判定（复刻 handle_request 受保护列表）
PROTECTED = {
    "/setTargetPkgJson", "/setInterceptDirs", "/clearLogs",
    "/getTargetPkgJson", "/getInterceptDirs", "/getCandidatesPkgJson",
}
OPEN = {"/getStatus", "/getLogs"}
def api_decision(path, headers):
    if path in PROTECTED:
        return origin_ok(headers) and header_token_valid(headers)
    return None  # 开放/未知

# ---------------------------------------------------------------
print("== A. token_valid 用例 ==")
check("正确令牌", header_token_valid("\r\nX-Auth-Token: " + TOKEN), True)
check("小写头名", header_token_valid("\r\nx-auth-token: " + TOKEN), True)
check("错误令牌", header_token_valid("\r\nX-Auth-Token: " + TOKEN[:-1] + "0"), False)
check("空值", header_token_valid("\r\nX-Auth-Token: \r\n"), False)
check("值带前后空格", header_token_valid("\r\nX-Auth-Token:   " + TOKEN + "  \r\n"), True)
check("多个头取首个", header_token_valid("\r\nX-Auth-Token: wrong\r\nx-auth-token: " + TOKEN), False)  # 首个非空为准
check("前缀截断绕行(x-auth-tokenX)",
      header_token_valid("\r\nx-auth-token: " + TOKEN + "X\r\n"), False)  # 13 位前缀后第 14 位非冒号→不匹配
check("头名带空格(x-auth-token :)", header_token_valid("\r\nx-auth-token : " + TOKEN), False)
check("无头", header_token_valid("\r\nHost: x\r\n"), False)
check("仅请求行", header_token_valid("POST /getStatus HTTP/1.1"), False)

print("== B. origin_ok 用例 ==")
check("无 Origin 放行", origin_ok(H("Host: x\r\n")), True)
check("KSU 页面 Origin(带端口)", origin_ok(H("Origin: http://127.0.0.1:52265\r\n")), True)
check("无端口 Origin", origin_ok(H("Origin: http://127.0.0.1\r\n")), True)
check("evil 域绕过", origin_ok(H("Origin: http://127.0.0.1.evil.com\r\n")), False)
check("https 拒绝", origin_ok(H("Origin: https://127.0.0.1:52265\r\n")), False)
check("其他地址拒绝", origin_ok(H("Origin: http://192.168.1.1:16080\r\n")), False)
check("短串拒绝", origin_ok(H("Origin: http://127\r\n")), False)
check("小写 origin 头名", origin_ok(H("origin: http://127.0.0.1:52265\r\n")), True)

print("== C. 路由 + 鉴权组合 ==")
ok_tok = H("Origin: http://127.0.0.1:52265\r\nX-Auth-Token: " + TOKEN + "\r\n")
no_origin_tok = H("X-Auth-Token: " + TOKEN + "\r\n")
for ap in sorted(PROTECTED):
    check(f"{ap} 带令牌+Origin -> 放行", api_decision(ap, ok_tok), True)
    check(f"{ap} 令牌无Origin -> 放行(非浏览器)", api_decision(ap, no_origin_tok), True)
    check(f"{ap} 无令牌 -> 403", api_decision(ap, H("Host: x\r\n")), False)
for ap in sorted(OPEN):
    check(f"{ap} 无令牌开放", api_decision(ap, H("Host: x\r\n")), None)
check("未知路径", api_decision("/xxx", ok_tok), None)

print(f"\n结果: {PASS} PASS / {FAIL} FAIL")
exit(1 if FAIL else 0)